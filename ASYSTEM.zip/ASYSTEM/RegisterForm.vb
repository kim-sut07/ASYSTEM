﻿Imports System.Data.SqlClient

Public Class RegisterForm

    Private Sub btnRegister_Click(sender As Object, e As EventArgs) Handles btnRegister.Click
        If txtNPass.Text <> txtCPass.Text Then
            MessageBox.Show("Passwords do not match")
            Return
        End If
        Try
            conn.Open()
            Dim cmd As New SqlCommand("INSERT INTO USER (Username,Password) VALUES (@Username,@Password)", conn)
            cmd.Parameters.AddWithValue("@Username", txtNUser.Text)
            cmd.Parameters.AddWithValue("@Password", txtNPass.Text)

            Dim result As Integer = cmd.ExecuteNonQuery()
            If result > 0 Then
                MessageBox.Show("Registration Successful")
                LoginForm.Show()
                Me.Hide()
            Else
                MessageBox.Show("Registration Failed")
            End If
            conn.Close()
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
    End Sub

    Private Sub LinkLabel1_LinkClicked(sender As Object, e As LinkLabelLinkClickedEventArgs) Handles LinkLabel1.LinkClicked
        LoginForm.Show()
        Me.Hide()
    End Sub
End Class