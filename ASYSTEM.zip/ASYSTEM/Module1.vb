﻿Imports System.Data.SqlClient

Module Module1
    Public conn As New SqlConnection("Data Source=127.0.0.1;Initial Catalog=teacherdb; Integrated Security=True")
End Module
